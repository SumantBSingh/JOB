﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Job.Business
{
    public class Business: IBusiness
    {
        public string GetMessage()
        {
            return "Say Hello";
        }
    }
}
