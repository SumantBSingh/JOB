﻿using Job.Business;
using Ninject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace WindowsJob
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        public void OnDebug()
        {
            OnStart(null);
        }
        protected override void OnStart(string[] args)
        {
            try
            {
                StandardKernel standardKernel = new StandardKernel();
                standardKernel.Load(Assembly.GetExecutingAssembly());
                standardKernel.Bind<IBusiness>().To<Business>();
                IBusiness business = standardKernel.Get<IBusiness>();
                Console.WriteLine(business.GetMessage());
            }
            catch (Exception ex)
            {

                //throw;
            }
            
        }
        protected override void OnStop()
        {
        }
    }
}
